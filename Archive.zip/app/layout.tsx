import "./globals.css";
import { Inter } from "next/font/google";
import { Metadata, ResolvingMetadata } from "next";

const inter = Inter({ subsets: ["latin"] });

export async function generateMetadata(
   parent?: ResolvingMetadata
): Promise<Metadata> {
   // read route params

   // fetch data
   const product = await fetch(`http://127.0.0.1:8000/api/metadata`).then(
      (res) => res.json()
   );

   // optionally access and extend (rather than replace) parent metadata

   return {
      title: "Keluarga Mazni",
   };
}
export default function RootLayout({
   children,
}: {
   children: React.ReactNode;
}) {
   return (
      <html lang="en">
         <body className={inter.className}>{children}</body>
      </html>
   );
}
